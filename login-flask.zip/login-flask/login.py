from flask import *
from flask_sqlalchemy import  SQLAlchemy
from flask_migrate import Migrate

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///user.db"
db = SQLAlchemy(app)
migrate = Migrate(app,db)

#Definir modelo cuenta
class cuenta(db.Model):
    usuario = db.Column(db.String(200),unique = True)
    password = db.Column(db.String(200))
    id_usuario = db.Column(db.Integer(), primary_key = True)

#Definir modelo respuesta
class respuesta(db.Model):
    text_answer = db.Column(db.String(200))
    id_answer = db.Column(db.Integer(),primary_key = True)

#Definir modelo recover
class recover(db.Model):
    id_recover = db.Column(db.Integer(),primary_key = True)
    id_usuario = db.Column(db.Integer(),db.ForeignKey("cuenta.id_usuario"))
    id_answer = db.Column(db.Integer(),db.ForeignKey("respuesta.id_answer"))


with app.app_context():
    db.create_all()

@app.route("/")
def home():
    return render_template("home.html")

#pag de registro
@app.route("/register", methods = ["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form["usuario"]
        password = request.form["password"]
        answer = request.form["rpta"]

        #Verificar si existe
        Euser = cuenta.query.filter_by(usuario=username).first()
        
        #Si la cuenta existe no se crea
        if Euser:
            return "El usuario ya esta registrado"
        
        #Crear cuenta
        new_account = cuenta(usuario=username,password=password)
        db.session.add(new_account)
        db.session.commit()

        # Crear respuesta
        new_answer = respuesta(text_answer=answer)
        db.session.add(new_answer)
        db.session.commit()

        # Asignar respuesta en la tabla recover
        new_recover = recover(id_usuario=new_account.id_usuario, id_answer = new_answer.id_answer)
        db.session.add(new_recover)
        db.session.commit()
        
        return redirect("/")

    return render_template("register.html")

#Pag log-in
@app.route("/login",methods = ["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        #Llamamos a la cuenta
        user = cuenta.query.filter_by(usuario = username,password = password)

        #Verificamos la existencia de la cuenta
        if user:
            return "Sesion iniciada Correctamente :D"
        else:
            return "No existe la cuenta"
    
    return render_template("log.html")

@app.route("/recoverpassword", methods = ["GET","POST"])
def securityquestion():
    if request.method == "POST":
        username = request.form["username"]
        user_answer = request.form["rpta"]

        # Verificar usuario
        user = cuenta.query.filter_by(usuario=username).first()
        if not user:
            return "Usuario no encontrado"

        
        # Verificar respuesta
        recover_entry = respuesta.query.filter_by(text_answer=user_answer).first()
        
        if recover_entry:
            return "Respuesta correcta."
        else:
            return "Respuesta incorrecta."
        
    return render_template("recover.html")

@app.route('/xd', method = ['GET','POST'])
def xd():
    return render_template('Goat')


if __name__ == "__main__":
    app.run(debug = True)